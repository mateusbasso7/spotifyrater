import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'model.dart';

class RatingStore {
  final Map<String, RatingEntry> entries = {};
  DateTime? lastExport;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('sideb_ratings_v1');
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        entries.clear();
        for (final item in list) {
          final entry = RatingEntry.fromJson(Map<String, dynamic>.from(item as Map));
          entries[entry.key] = entry;
        }
      } catch (_) {
        // Um arquivo corrompido não impede que o app seja aberto.
      }
    }
    final date = prefs.getString('sideb_last_export');
    lastExport = date == null ? null : DateTime.tryParse(date);
  }

  Future<void> save(Song song, double rating) async {
    if (rating == 0) {
      entries.remove(song.key);
    } else {
      entries[song.key] = RatingEntry.fromSong(song, rating);
    }
    await _persist();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'sideb_ratings_v1', jsonEncode(entries.values.map((e) => e.toJson()).toList()),
    );
  }

  double ratingOf(Song song) => entries[song.key]?.rating ?? 0;

  bool get shouldRemind {
    if (entries.isEmpty) return false;
    final reference = lastExport ?? entries.values
        .map((e) => DateTime.tryParse(e.updatedAt))
        .whereType<DateTime>()
        .fold<DateTime>(DateTime.now(), (prev, date) => date.isBefore(prev) ? date : prev);
    return DateTime.now().difference(reference).inDays >= 7;
  }

  List<Map<String, dynamic>> get albumSummaries {
    final groups = <String, List<RatingEntry>>{};
    for (final e in entries.values) {
      groups.putIfAbsent('${e.platform}|${Song.normalized(e.album)}', () => []).add(e);
    }
    return groups.values.map((group) {
      final total = group.map((e) => e.albumTotalTracks).whereType<int>()
          .fold<int>(0, (a, b) => a > b ? a : b);
      return <String, dynamic>{
        'platform': group.first.platform,
        'album': group.first.album,
        'average': group.fold<double>(0, (sum, e) => sum + e.rating) / group.length,
        'ratedTracks': group.length,
        'totalTracks': total == 0 ? null : total,
        'isPartial': total == 0 || group.length < total,
      };
    }).toList();
  }

  Future<void> exportJson() async {
    final data = {
      'format': 'sideb-ratings',
      'version': 1,
      'exportedAt': DateTime.now().toIso8601String(),
      'ratings': entries.values.map((entry) => entry.toJson()).toList(),
      'albums': albumSummaries,
    };
    final file = File('${(await getTemporaryDirectory()).path}/sideb_avaliacoes_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(prettyJson(data));
    await Share.shareXFiles([XFile(file.path)], text: 'Meu backup Side B');
    lastExport = DateTime.now();
    (await SharedPreferences.getInstance()).setString('sideb_last_export', lastExport!.toIso8601String());
  }

  String exportCsvContent() {
    String csv(String value) => '"${value.replaceAll('"', '""')}"';
    final lines = <String>['plataforma,artista,album,musica,nota,atualizado_em,media_album,faixas_avaliadas,total_faixas,media_parcial'];
    final albums = {
      for (final album in albumSummaries)
        '${album['platform']}|${Song.normalized(album['album'] as String)}': album,
    };
    for (final e in entries.values) {
      final album = albums['${e.platform}|${Song.normalized(e.album)}']!;
      lines.add([
        e.platform, e.artist, e.album, e.title,
        e.rating.toStringAsFixed(1), e.updatedAt,
        (album['average'] as double).toStringAsFixed(2),
        '${album['ratedTracks']}', '${album['totalTracks'] ?? ''}',
        '${album['isPartial']}',
      ].map(csv).join(','));
    }
    return '\uFEFF${lines.join('\r\n')}';
  }

  Future<void> exportCsv() async {
    final file = File('${(await getTemporaryDirectory()).path}/sideb_avaliacoes_${DateTime.now().millisecondsSinceEpoch}.csv');
    await file.writeAsString(exportCsvContent());
    await Share.shareXFiles([XFile(file.path)], text: 'Avaliações Side B (CSV)');
    lastExport = DateTime.now();
    (await SharedPreferences.getInstance()).setString('sideb_last_export', lastExport!.toIso8601String());
  }

  Future<int?> importJson() async {
    final selected = await FilePicker.platform.pickFiles(
      type: FileType.custom, allowedExtensions: ['json'], withData: true,
    );
    if (selected == null) return null;
    final source = selected.files.single;
    final bytes = source.bytes ?? (source.path != null ? await File(source.path!).readAsBytes() : null);
    if (bytes == null) throw FormatException('Não foi possível ler o arquivo.');
    final doc = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
    if (doc['format'] != 'sideb-ratings' || doc['version'] != 1 || doc['ratings'] is! List) {
      throw const FormatException('O arquivo não é um backup Side B válido.');
    }
    int imported = 0;
    for (final j in doc['ratings'] as List) {
      final entry = RatingEntry.fromJson(Map<String, dynamic>.from(j as Map));
      if (entry.rating < 0.5 || entry.rating > 5 || entry.rating * 2 != (entry.rating * 2).round()) continue;
      entries[entry.key] = entry;
      imported++;
    }
    await _persist();
    return imported;
  }
}
