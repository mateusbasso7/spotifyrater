import 'dart:convert';

class Song {
  final String title;
  final String artist;
  final String album;
  final String platform;
  final String? imageUrl;
  final String? imageBase64;
  final int durationMs;
  final int positionMs;
  final bool playing;
  final int? albumTotalTracks;

  const Song({
    required this.title,
    required this.artist,
    required this.album,
    required this.platform,
    this.imageUrl,
    this.imageBase64,
    this.durationMs = 0,
    this.positionMs = 0,
    this.playing = false,
    this.albumTotalTracks,
  });

  String get key => '$platform|${normalized(artist)}|${normalized(title)}';
  String get albumKey => '$platform|${normalized(album)}';

  static String normalized(String s) => s
      .toLowerCase()
      .trim()
      .replaceAll(RegExp(r'\s+'), ' ')
      .replaceAll(RegExp(r'[^a-z0-9À-ÿ ]'), '');

  factory Song.fromMedia(Map<dynamic, dynamic> json, String source) => Song(
        title: '${json['title'] ?? ''}',
        artist: '${json['artist'] ?? ''}',
        album: '${json['album'] ?? 'Álbum desconhecido'}',
        platform: source,
        imageUrl: json['imageUrl'] as String?,
        imageBase64: json['imageBase64'] as String?,
        durationMs: (json['duration'] as num?)?.toInt() ?? 0,
        positionMs: (json['position'] as num?)?.toInt() ?? 0,
        playing: json['playing'] == true,
      );

  factory Song.fromSpotify(Map<String, dynamic> item,
      {bool playing = false, int positionMs = 0}) {
    final album = (item['album'] as Map?)?.cast<String, dynamic>() ?? {};
    final artists = (item['artists'] as List?) ?? [];
    final images = (album['images'] as List?) ?? [];
    return Song(
      title: '${item['name'] ?? ''}',
      artist: artists.map((e) => '${(e as Map)['name']}').join(', '),
      album: '${album['name'] ?? 'Álbum desconhecido'}',
      platform: 'spotify',
      imageUrl: images.isNotEmpty ? '${(images.first as Map)['url']}' : null,
      durationMs: (item['duration_ms'] as num?)?.toInt() ?? 0,
      positionMs: positionMs,
      playing: playing,
      albumTotalTracks: (album['total_tracks'] as num?)?.toInt(),
    );
  }
}

class RatingEntry {
  final String key;
  final String title;
  final String artist;
  final String album;
  final String platform;
  final String? imageUrl;
  final int? albumTotalTracks;
  final double rating;
  final String updatedAt;

  RatingEntry({
    required this.key,
    required this.title,
    required this.artist,
    required this.album,
    required this.platform,
    required this.rating,
    required this.updatedAt,
    this.imageUrl,
    this.albumTotalTracks,
  });

  factory RatingEntry.fromSong(Song song, double value) => RatingEntry(
        key: song.key,
        title: song.title,
        artist: song.artist,
        album: song.album,
        platform: song.platform,
        rating: value,
        updatedAt: DateTime.now().toIso8601String(),
        imageUrl: song.imageUrl,
        albumTotalTracks: song.albumTotalTracks,
      );

  Map<String, dynamic> toJson() => {
        'key': key,
        'title': title,
        'artist': artist,
        'album': album,
        'platform': platform,
        'rating': rating,
        'updatedAt': updatedAt,
        'imageUrl': imageUrl,
        'albumTotalTracks': albumTotalTracks,
      };

  factory RatingEntry.fromJson(Map<String, dynamic> j) => RatingEntry(
        key: '${j['key']}',
        title: '${j['title'] ?? ''}',
        artist: '${j['artist'] ?? ''}',
        album: '${j['album'] ?? 'Álbum desconhecido'}',
        platform: '${j['platform'] ?? 'spotify'}',
        rating: (j['rating'] as num).toDouble(),
        updatedAt: '${j['updatedAt'] ?? DateTime.now().toIso8601String()}',
        imageUrl: j['imageUrl'] as String?,
        albumTotalTracks: (j['albumTotalTracks'] as num?)?.toInt(),
      );
}

String prettyJson(Object value) => const JsonEncoder.withIndent('  ').convert(value);
