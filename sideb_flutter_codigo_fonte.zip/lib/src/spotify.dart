import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:app_links/app_links.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'model.dart';

class SpotifyClient {
  // Client ID público. Nunca embutir Client Secret em aplicativo móvel.
  static const clientId = 'f2faa3f3a4784c64bc6bcdbf90e23e9d';
  static const redirectUri = 'sideb://callback';
  static const scopes = 'user-read-currently-playing user-read-playback-state user-modify-playback-state';
  static const secure = FlutterSecureStorage();

  String? _accessToken;
  String? _refreshToken;
  DateTime? _expiresAt;
  StreamSubscription<Uri>? _linksSub;
  final onStatusChanged = StreamController<String>.broadcast();

  bool get connected => _accessToken != null || _refreshToken != null;

  Future<void> init() async {
    _accessToken = await secure.read(key: 'spotify_access');
    _refreshToken = await secure.read(key: 'spotify_refresh');
    final expiry = await secure.read(key: 'spotify_expiry');
    _expiresAt = expiry == null ? null : DateTime.tryParse(expiry);
    _linksSub = AppLinks().uriLinkStream.listen(_handleRedirect);
  }

  String _randomString() {
    final r = Random.secure();
    return base64UrlEncode(List<int>.generate(64, (_) => r.nextInt(256))).replaceAll('=', '');
  }

  Future<void> login() async {
    final verifier = _randomString();
    final state = _randomString();
    await secure.write(key: 'spotify_verifier', value: verifier);
    await secure.write(key: 'spotify_state', value: state);
    final challenge = base64UrlEncode(sha256.convert(ascii.encode(verifier)).bytes).replaceAll('=', '');
    final url = Uri.https('accounts.spotify.com', '/authorize', {
      'client_id': clientId,
      'response_type': 'code',
      'redirect_uri': redirectUri,
      'scope': scopes,
      'code_challenge_method': 'S256',
      'code_challenge': challenge,
      'state': state,
    });
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw StateError('Não foi possível abrir a autorização do Spotify.');
    }
  }

  Future<void> _handleRedirect(Uri uri) async {
    if (uri.scheme != 'sideb' || uri.host != 'callback') return;
    try {
      if (uri.queryParameters['error'] != null) throw StateError('Autorização cancelada.');
      final state = await secure.read(key: 'spotify_state');
      final verifier = await secure.read(key: 'spotify_verifier');
      if (state == null || verifier == null || uri.queryParameters['state'] != state) {
        throw StateError('Falha de validação da autorização.');
      }
      final code = uri.queryParameters['code'];
      if (code == null) throw StateError('Código de autorização ausente.');
      final response = await http.post(Uri.parse('https://accounts.spotify.com/api/token'),
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: {
            'grant_type': 'authorization_code',
            'code': code,
            'redirect_uri': redirectUri,
            'client_id': clientId,
            'code_verifier': verifier,
          });
      if (response.statusCode != 200) throw StateError('Spotify: falha ao conectar (${response.statusCode}).');
      await _saveTokens(jsonDecode(response.body) as Map<String, dynamic>);
      await secure.delete(key: 'spotify_state');
      await secure.delete(key: 'spotify_verifier');
      onStatusChanged.add('Spotify conectado!');
    } catch (e) {
      onStatusChanged.add('$e');
    }
  }

  Future<void> _saveTokens(Map<String, dynamic> data) async {
    _accessToken = data['access_token'] as String?;
    _refreshToken = (data['refresh_token'] as String?) ?? _refreshToken;
    _expiresAt = DateTime.now().add(Duration(seconds: ((data['expires_in'] as num?)?.toInt() ?? 3600) - 60));
    if (_accessToken != null) await secure.write(key: 'spotify_access', value: _accessToken);
    if (_refreshToken != null) await secure.write(key: 'spotify_refresh', value: _refreshToken);
    if (_expiresAt != null) await secure.write(key: 'spotify_expiry', value: _expiresAt!.toIso8601String());
  }

  Future<String?> _token() async {
    if (_accessToken != null && _expiresAt != null && DateTime.now().isBefore(_expiresAt!)) return _accessToken;
    if (_refreshToken == null) return null;
    final response = await http.post(Uri.parse('https://accounts.spotify.com/api/token'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'grant_type': 'refresh_token',
          'refresh_token': _refreshToken!,
          'client_id': clientId,
        });
    if (response.statusCode != 200) {
      throw StateError('Sessão expirada. Reconecte sua conta (${response.statusCode}).');
    }
    await _saveTokens(jsonDecode(response.body) as Map<String, dynamic>);
    return _accessToken;
  }

  Future<http.Response?> _api(String method, String path, {Map<String, String>? params}) async {
    final token = await _token();
    if (token == null) return null;
    final uri = Uri.https('api.spotify.com', '/v1/$path', params);
    late http.Response response;
    if (method == 'POST') {
      response = await http.post(uri, headers: {'Authorization': 'Bearer $token'});
    } else if (method == 'PUT') {
      response = await http.put(uri, headers: {'Authorization': 'Bearer $token'});
    } else {
      response = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    }
    if (response.statusCode == 403) {
      throw StateError('Spotify recusou o acesso (403). Confira Premium e usuários autorizados no Dashboard.');
    }
    if (response.statusCode == 429) throw StateError('Limite de requisições Spotify. Tente novamente em instantes.');
    if (response.statusCode >= 400) throw StateError('Spotify respondeu ${response.statusCode}.');
    return response;
  }

  Future<Song?> currentlyPlaying() async {
    final response = await _api('GET', 'me/player/currently-playing');
    if (response == null || response.statusCode == 204 || response.body.isEmpty) return null;
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (body['currently_playing_type'] != 'track' || body['item'] is! Map) return null;
    return Song.fromSpotify(Map<String, dynamic>.from(body['item'] as Map),
        playing: body['is_playing'] == true,
        positionMs: (body['progress_ms'] as num?)?.toInt() ?? 0);
  }

  Future<List<Song>> search(String term) async {
    if (term.trim().isEmpty) return [];
    final response = await _api('GET', 'search', params: {'q': term, 'type': 'track', 'limit': '10'});
    if (response == null || response.body.isEmpty) return [];
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    final tracks = (body['tracks'] as Map?)?['items'] as List? ?? [];
    return tracks.map((item) => Song.fromSpotify(Map<String, dynamic>.from(item as Map))).toList();
  }

  Future<bool> control(String action, {bool playing = false}) async {
    final route = switch (action) {
      'next' => 'me/player/next',
      'previous' => 'me/player/previous',
      'playPause' => playing ? 'me/player/pause' : 'me/player/play',
      _ => '',
    };
    if (route.isEmpty) return false;
    final method = action == 'playPause' ? 'PUT' : 'POST';
    final result = await _api(method, route);
    return result != null && (result.statusCode == 204 || result.statusCode == 200 || result.statusCode == 202);
  }

  Future<void> logout() async {
    for (final name in ['spotify_access', 'spotify_refresh', 'spotify_expiry', 'spotify_state', 'spotify_verifier']) {
      await secure.delete(key: name);
    }
    _accessToken = null;
    _refreshToken = null;
    _expiresAt = null;
    onStatusChanged.add('Spotify desconectado.');
  }

  void dispose() {
    _linksSub?.cancel();
    onStatusChanged.close();
  }
}
