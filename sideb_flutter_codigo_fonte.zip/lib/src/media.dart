import 'package:flutter/services.dart';

import 'model.dart';

class AndroidMediaClient {
  static const _channel = MethodChannel('com.sideb.musicratings/media');

  Future<bool> get hasPermission async => await _channel.invokeMethod<bool>('hasPermission') ?? false;

  Future<void> openSettings() async => _channel.invokeMethod<void>('requestPermission');

  Future<Song?> currentlyPlaying(String platform) async {
    try {
      final data = await _channel.invokeMapMethod<dynamic, dynamic>('current', {'platform': platform});
      if (data == null || '${data['title'] ?? ''}'.trim().isEmpty) return null;
      return Song.fromMedia(data, platform);
    } on PlatformException {
      return null;
    }
  }

  Future<bool> control(String platform, String action) async {
    return await _channel.invokeMethod<bool>('control', {'platform': platform, 'action': action}) ?? false;
  }
}
