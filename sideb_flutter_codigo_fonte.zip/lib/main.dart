import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'src/media.dart';
import 'src/model.dart';
import 'src/spotify.dart';
import 'src/storage.dart';

const bg = Color(0xFF0B0D0E);
const surface = Color(0xFF202426);
const surface2 = Color(0xFF2A2F31);
const accent = Color(0xFFC7FB6B);
const muted = Color(0xFFB2B5B1);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SideBApp());
}

class SideBApp extends StatelessWidget {
  const SideBApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Side B.',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: accent, surface: surface),
          fontFamily: 'Roboto',
          textTheme: const TextTheme(
            headlineLarge: TextStyle(fontSize: 33, fontWeight: FontWeight.w900, height: 1.02, letterSpacing: -1.3),
            titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          cardTheme: CardThemeData(color: surface, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: surface,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            hintStyle: const TextStyle(color: muted),
          ),
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final SpotifyClient spotify = SpotifyClient();
  final AndroidMediaClient media = AndroidMediaClient();
  final RatingStore store = RatingStore();
  final TextEditingController searchController = TextEditingController();

  StreamSubscription<String>? authEvents;
  Timer? polling;
  Song? current;
  String source = 'spotify';
  int tab = 0;
  bool initialized = false;
  bool mediaPermission = false;
  bool searching = false;
  bool refreshing = false;
  List<Song> results = [];
  DateTime lastSpotifyCheck = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _start();
  }

  Future<void> _start() async {
    try {
      await store.load();
      await spotify.init();
      authEvents = spotify.onStatusChanged.stream.listen((message) {
        if (!mounted) return;
        setState(() {});
        _toast(message);
        _refresh(force: true);
      });
      mediaPermission = await media.hasPermission;
      polling = Timer.periodic(const Duration(seconds: 5), (_) => _refresh());
    } catch (e) {
      _toast('Não foi possível iniciar: $e');
    }
    if (!mounted) return;
    setState(() => initialized = true);
    _refresh(force: true);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkPermission();
      _refresh(force: true);
    }
  }

  Future<void> _checkPermission() async {
    final granted = await media.hasPermission;
    if (mounted) setState(() => mediaPermission = granted);
  }

  Future<void> _refresh({bool force = false}) async {
    if (refreshing) return;
    refreshing = true;
    try {
      Song? song;
      if (source == 'spotify' && spotify.connected &&
          (force || DateTime.now().difference(lastSpotifyCheck).inSeconds >= 20)) {
        lastSpotifyCheck = DateTime.now();
        try {
          song = await spotify.currentlyPlaying();
        } catch (e) {
          if (force) _toast('$e');
        }
      }
      if (song == null && mediaPermission) {
        song = await media.currentlyPlaying(source);
      }
      // Não apague o player se ainda estamos entre duas consultas válidas da API.
      if (mounted && (song != null || force || source == 'youtube')) {
        setState(() => current = song);
      }
    } finally {
      refreshing = false;
    }
  }

  Future<void> _rating(Song song, double value) async {
    await store.save(song, value);
    if (mounted) setState(() {});
    _toast(value == 0 ? 'Nota removida' : 'Avaliação salva: ${value.toStringAsFixed(1)} estrelas');
  }

  Future<void> _control(String action) async {
    try {
      var worked = await media.control(source, action);
      if (!worked && source == 'spotify' && spotify.connected) {
        worked = await spotify.control(action, playing: current?.playing ?? false);
      }
      if (!worked) {
        _toast('Abra o player ou conceda acesso às sessões de mídia.');
        return;
      }
      await Future<void>.delayed(const Duration(milliseconds: 450));
      await _refresh(force: true);
    } catch (e) {
      _toast('$e');
    }
  }

  Future<void> _search() async {
    final query = searchController.text.trim();
    if (query.isEmpty) return;
    if (!spotify.connected) {
      _toast('Conecte sua conta Spotify para pesquisar no catálogo.');
      return;
    }
    setState(() => searching = true);
    try {
      final found = await spotify.search(query);
      if (mounted) setState(() => results = found);
    } catch (e) {
      _toast('$e');
    } finally {
      if (mounted) setState(() => searching = false);
    }
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message), backgroundColor: surface2,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 4),
    ));
  }

  @override
  void dispose() {
    polling?.cancel();
    authEvents?.cancel();
    spotify.dispose();
    searchController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 76,
        backgroundColor: bg,
        title: const Row(children: [
          Text('side ', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -1.7)),
          Text('b.', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: accent, letterSpacing: -1.7)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Atualizar player',
            onPressed: () => _refresh(force: true),
            icon: const Icon(Icons.refresh_rounded),
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: !initialized
          ? const Center(child: CircularProgressIndicator(color: accent))
          : SafeArea(child: switch (tab) {
              0 => _nowView(),
              1 => _albumsView(),
              2 => _searchView(),
              _ => _dataView(),
            }),
      bottomNavigationBar: NavigationBar(
        height: 76,
        backgroundColor: const Color(0xFF131616),
        indicatorColor: const Color(0xFF38482B),
        selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.headphones_outlined), selectedIcon: Icon(Icons.headphones, color: accent), label: 'Agora'),
          NavigationDestination(icon: Icon(Icons.album_outlined), selectedIcon: Icon(Icons.album, color: accent), label: 'Álbuns'),
          NavigationDestination(icon: Icon(Icons.search), selectedIcon: Icon(Icons.manage_search, color: accent), label: 'Buscar'),
          NavigationDestination(icon: Icon(Icons.ios_share_outlined), selectedIcon: Icon(Icons.ios_share, color: accent), label: 'Dados'),
        ],
      ),
    );
  }

  Widget _nowView() => ListView(
        padding: const EdgeInsets.fromLTRB(22, 8, 22, 28),
        children: [
          const Text('SEU DIÁRIO MUSICAL', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: 2)),
          const SizedBox(height: 7),
          Text('Sua música.\nSeu veredito.', style: Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height: 8),
          const Text('Cada faixa merece uma nota.', style: TextStyle(color: muted)),
          const SizedBox(height: 25),
          _sourcePicker(),
          const SizedBox(height: 27),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('OUVINDO AGORA', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1.8, fontWeight: FontWeight.w900)),
            Text(source == 'spotify' ? 'SPOTIFY' : 'YOUTUBE MUSIC', style: const TextStyle(fontSize: 10, letterSpacing: 1, color: accent, fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 13),
          if (store.shouldRemind) _reminder(),
          if (current == null) ...[
            _placeholder(),
            const SizedBox(height: 18),
            Text('Nenhuma música detectada', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            const Text('Abra uma música no aplicativo escolhido e volte aqui.', style: TextStyle(color: muted), textAlign: TextAlign.center),
            const SizedBox(height: 19),
            _connectionCard(),
          ] else ...[
            Artwork(song: current!, size: null, radius: 22),
            const SizedBox(height: 18),
            Text(current!.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text(current!.artist, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, color: muted)),
            const SizedBox(height: 4),
            Text(current!.album, textAlign: TextAlign.center, style: const TextStyle(color: accent, fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 20),
            _progressBar(current!),
            const SizedBox(height: 13),
            _controls(),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(19),
              decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white12)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Qual é a sua nota?', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  Text('${store.ratingOf(current!).toStringAsFixed(1)} / 5', style: const TextStyle(color: accent, fontSize: 15, fontWeight: FontWeight.bold)),
                ]),
                const SizedBox(height: 12),
                StarPicker(value: store.ratingOf(current!), onChanged: (v) => _rating(current!, v)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Toque em meia estrela para notas de 0,5', style: TextStyle(color: muted, fontSize: 10)),
                  TextButton(onPressed: () => _rating(current!, 0), child: const Text('Limpar', style: TextStyle(color: muted, fontSize: 11))),
                ]),
              ]),
            ),
            const SizedBox(height: 16),
            _connectionCard(),
          ],
        ],
      );

  Widget _sourcePicker() => Container(
        padding: const EdgeInsets.all(5),
        decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)),
        child: Row(children: [
          Expanded(child: _sourceButton('spotify', 'Spotify', Icons.graphic_eq)),
          Expanded(child: _sourceButton('youtube', 'YouTube Music', Icons.play_circle_fill_rounded)),
        ]),
      );

  Widget _sourceButton(String id, String label, IconData icon) => InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          setState(() {
            source = id;
            current = null;
          });
          _refresh(force: true);
        },
        child: Container(
          height: 46,
          decoration: BoxDecoration(color: source == id ? const Color(0xFF333839) : Colors.transparent, borderRadius: BorderRadius.circular(14)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: id == 'spotify' ? const Color(0xFF1ED760) : const Color(0xFFFF4655), size: 20),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(fontSize: 13, fontWeight: source == id ? FontWeight.bold : FontWeight.w500)),
          ]),
        ),
      );

  Widget _placeholder() => AspectRatio(
        aspectRatio: 1.2,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF303535), Color(0xFF111515), Color(0xFF35482A)]),
          ),
          child: const Center(child: Icon(Icons.library_music_rounded, color: accent, size: 100)),
        ),
      );

  Widget _connectionCard() => Container(
        decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(18)),
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(source == 'spotify' ? 'Sua conta Spotify' : 'YouTube Music no Android', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 7),
          Text(source == 'spotify'
              ? (spotify.connected ? 'Conta autorizada. Para ler o player local, habilite também o acesso às sessões de mídia.' : 'Conecte sua conta para ler músicas e pesquisar no catálogo.')
              : 'Não existe login oficial de YouTube Music aqui: lemos a sessão de mídia autorizada pelo Android.',
              style: const TextStyle(fontSize: 12, color: muted)),
          const SizedBox(height: 12),
          if (source == 'spotify') ...[
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: () async {
                try {
                  if (spotify.connected) {
                    await spotify.logout();
                    if (mounted) setState(() {});
                  } else {
                    await spotify.login();
                  }
                } catch (e) { _toast('$e'); }
              },
              icon: Icon(spotify.connected ? Icons.logout : Icons.login),
              label: Text(spotify.connected ? 'Desconectar Spotify' : 'Conectar Spotify'),
            )),
            const SizedBox(height: 7),
          ],
          OutlinedButton.icon(
            onPressed: () => media.openSettings(),
            icon: Icon(mediaPermission ? Icons.check_circle : Icons.settings),
            label: Text(mediaPermission ? 'Acesso à mídia habilitado' : 'Autorizar acesso à mídia'),
          ),
        ]),
      );

  Widget _reminder() => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => setState(() => tab = 3),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: const Color(0xFF28341E), borderRadius: BorderRadius.circular(14)),
            child: const Row(children: [
              Icon(Icons.backup_outlined, color: accent), SizedBox(width: 12),
              Expanded(child: Text('Já faz uma semana! Exporte suas avaliações para manter um backup.', style: TextStyle(fontSize: 12))),
              Icon(Icons.chevron_right, color: accent),
            ]),
          ),
        ),
      );

  Widget _progressBar(Song song) {
    final fraction = song.durationMs <= 0 ? 0.0 : (song.positionMs / song.durationMs).clamp(0.0, 1.0).toDouble();
    return Column(children: [
      LinearProgressIndicator(value: fraction, backgroundColor: surface2, color: accent, minHeight: 4, borderRadius: BorderRadius.circular(4)),
      const SizedBox(height: 6),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(_mmss(song.positionMs), style: const TextStyle(color: muted, fontSize: 11)),
        Text(_mmss(song.durationMs), style: const TextStyle(color: muted, fontSize: 11)),
      ]),
    ]);
  }

  String _mmss(int ms) => '${Duration(milliseconds: math.max(0, ms)).inMinutes}:${(Duration(milliseconds: math.max(0, ms)).inSeconds % 60).toString().padLeft(2, '0')}';

  Widget _controls() => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(iconSize: 30, onPressed: () => _control('previous'), icon: const Icon(Icons.skip_previous_rounded)),
        const SizedBox(width: 26),
        Container(
          decoration: const BoxDecoration(color: accent, shape: BoxShape.circle),
          child: IconButton(iconSize: 32, color: bg, onPressed: () => _control('playPause'),
              icon: Icon(current?.playing == true ? Icons.pause_rounded : Icons.play_arrow_rounded)),
        ),
        const SizedBox(width: 26),
        IconButton(iconSize: 30, onPressed: () => _control('next'), icon: const Icon(Icons.skip_next_rounded)),
      ]);

  Widget _albumsView() {
    final groups = <String, List<RatingEntry>>{};
    for (final entry in store.entries.values) {
      final albumKey = '${entry.platform}|${Song.normalized(entry.album)}';
      groups.putIfAbsent(albumKey, () => []).add(entry);
    }
    final albums = groups.values.toList()..sort((a, b) => a.first.album.toLowerCase().compareTo(b.first.album.toLowerCase()));
    return ListView(padding: const EdgeInsets.fromLTRB(22, 12, 22, 24), children: [
      Text('Seus álbuns.', style: Theme.of(context).textTheme.headlineLarge),
      const SizedBox(height: 8),
      Text('${albums.length} álbuns com avaliações salvas', style: const TextStyle(color: muted)),
      const SizedBox(height: 22),
      if (albums.isEmpty) _emptyCard('Nenhum álbum ainda', 'Avalie uma música para começar sua biblioteca.', Icons.album_outlined),
      for (final album in albums) Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AlbumPage(album: album))),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(17)),
            child: Row(children: [
              Artwork(song: Song(title: '', artist: '', album: album.first.album, platform: album.first.platform, imageUrl: album.first.imageUrl), size: 74, radius: 12),
              const SizedBox(width: 13),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(album.first.album, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                Text('${album.length} músicas avaliadas • ${album.first.platform == 'spotify' ? 'Spotify' : 'YouTube Music'}', style: const TextStyle(color: muted, fontSize: 11)),
                const SizedBox(height: 4),
                Text('Média ${_mean(album).toStringAsFixed(2)} / 5${_albumIncomplete(album) ? ' • parcial' : ''}', style: const TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 12)),
              ])),
              const Icon(Icons.chevron_right, color: muted),
            ]),
          ),
        ),
      ),
    ]);
  }

  static double _mean(List<RatingEntry> album) => album.fold<double>(0, (sum, entry) => sum + entry.rating) / album.length;
  static bool _albumIncomplete(List<RatingEntry> album) {
    final count = album.map((e) => e.albumTotalTracks).whereType<int>().fold<int>(0, (a, b) => math.max(a, b));
    return count == 0 || album.length < count;
  }

  Widget _searchView() {
    final locallyFiltered = store.entries.values.where((r) =>
      '${r.title} ${r.artist} ${r.album}'.toLowerCase().contains(searchController.text.toLowerCase().trim())).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(22, 12, 22, 25), children: [
      Text('Buscar música.', style: Theme.of(context).textTheme.headlineLarge),
      const SizedBox(height: 8),
      const Text('Encontre faixas, descubra álbuns e avalie sem sair do Side B.', style: TextStyle(color: muted)),
      const SizedBox(height: 22),
      TextField(
        controller: searchController,
        textInputAction: TextInputAction.search,
        onSubmitted: (_) => _search(),
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          prefixIcon: const Icon(Icons.search, color: accent),
          hintText: 'Artista, música ou álbum...',
          suffixIcon: IconButton(onPressed: _search, icon: const Icon(Icons.arrow_forward_rounded, color: accent)),
        ),
      ),
      const SizedBox(height: 18),
      if (!spotify.connected) _emptyCard('Conecte o Spotify', 'A pesquisa online utiliza a API oficial do Spotify. Suas notas locais continuam disponíveis.', Icons.lock_outline),
      if (searching) const Center(child: CircularProgressIndicator(color: accent)),
      if (results.isNotEmpty) ...[
        const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('RESULTADOS NO SPOTIFY', style: TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5))),
        for (final song in results) _songTile(song),
      ],
      if (locallyFiltered.isNotEmpty) ...[
        const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('SUAS AVALIAÇÕES', style: TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5))),
        for (final rating in locallyFiltered.take(30)) ListTile(
          title: Text(rating.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${rating.artist} • ${rating.album}', maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Text('★ ${rating.rating.toStringAsFixed(1)}', style: const TextStyle(color: accent)),
        ),
      ],
      const SizedBox(height: 18),
      const Text('O YouTube Music não oferece uma API oficial equivalente para pesquisa musical. É possível avaliar suas faixas quando estiverem em reprodução.', style: TextStyle(fontSize: 12, color: muted)),
    ]);
  }

  Widget _songTile(Song song) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 3),
          leading: Artwork(song: song, size: 52, radius: 9),
          title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${song.artist} • ${song.album}', maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Text(store.ratingOf(song) > 0 ? '★ ${store.ratingOf(song).toStringAsFixed(1)}' : '☆', style: const TextStyle(fontSize: 19, color: accent)),
          onTap: () => _openRatingSheet(song),
        ),
      );

  void _openRatingSheet(Song song) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, sheetSetState) => Padding(
        padding: EdgeInsets.fromLTRB(24, 28, 24, MediaQuery.viewInsetsOf(ctx).bottom + 38),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Artwork(song: song, size: 120, radius: 14),
          const SizedBox(height: 15),
          Text(song.title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
          const SizedBox(height: 5),
          Text(song.artist, textAlign: TextAlign.center, style: const TextStyle(color: muted)),
          const SizedBox(height: 18),
          StarPicker(value: store.ratingOf(song), onChanged: (value) async {
            await _rating(song, value);
            sheetSetState(() {});
          }),
          const SizedBox(height: 12),
          Text('${store.ratingOf(song).toStringAsFixed(1)} / 5', style: const TextStyle(color: accent, fontWeight: FontWeight.bold)),
          TextButton(onPressed: () async {
            await _rating(song, 0);
            sheetSetState(() {});
          }, child: const Text('Remover avaliação')),
        ]),
      )),
    );
  }

  Widget _dataView() => ListView(padding: const EdgeInsets.fromLTRB(22, 12, 22, 26), children: [
        Text('Suas notas.\nSeus dados.', style: Theme.of(context).textTheme.headlineLarge),
        const SizedBox(height: 10),
        const Text('Sem conta no Side B, sem banco de dados remoto. Suas notas ficam neste aparelho.', style: TextStyle(color: muted)),
        const SizedBox(height: 26),
        Row(children: [
          Expanded(child: _statBox('${store.entries.length}', 'MÚSICAS')),
          const SizedBox(width: 11),
          Expanded(child: _statBox('${store.entries.values.map((r) => '${r.platform}|${Song.normalized(r.album)}').toSet().length}', 'ÁLBUNS')),
        ]),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Backup de avaliações', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 19)),
            const SizedBox(height: 6),
            const Text('Salve no aparelho, Google Drive ou outro destino pelo menu de compartilhamento do Android.', style: TextStyle(color: muted, fontSize: 12)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: store.entries.isEmpty ? null : () => _backup(() => store.exportJson()),
              icon: const Icon(Icons.file_download_outlined), label: const Text('Exportar backup JSON'),
            )),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(
              onPressed: store.entries.isEmpty ? null : () => _backup(() => store.exportCsv()),
              icon: const Icon(Icons.table_rows_outlined), label: const Text('Exportar planilha CSV'),
            )),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(
              onPressed: () async {
                try {
                  final count = await store.importJson();
                  if (mounted) setState(() {});
                  if (count != null) _toast('$count avaliações importadas.');
                } catch (e) { _toast('Erro ao importar: $e'); }
              },
              icon: const Icon(Icons.file_upload_outlined), label: const Text('Importar backup JSON'),
            )),
          ]),
        ),
        const SizedBox(height: 17),
        Container(
          padding: const EdgeInsets.all(19),
          decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(20)),
          child: Row(children: [
            const Icon(Icons.notifications_active_outlined, color: accent),
            const SizedBox(width: 15),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Lembrete semanal', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text('O Side B exibe um aviso dentro do aplicativo após 7 dias sem exportar.', style: TextStyle(color: muted, fontSize: 12)),
            ])),
          ]),
        ),
        const SizedBox(height: 17),
        const Text('Importante: desinstalar o aplicativo ou limpar seus dados pode apagar as avaliações locais. Exporte o JSON regularmente.', style: TextStyle(color: muted, fontSize: 12)),
      ]);

  Future<void> _backup(Future<void> Function() operation) async {
    try {
      await operation();
      if (mounted) setState(() {});
    } catch (e) { _toast('Falha na exportação: $e'); }
  }

  Widget _statBox(String value, String label) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: const TextStyle(fontSize: 31, color: accent, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text(label, style: const TextStyle(color: muted, letterSpacing: 1.6, fontSize: 11, fontWeight: FontWeight.bold)),
        ]),
      );

  Widget _emptyCard(String heading, String subtitle, IconData icon) => Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(20)),
        child: Column(children: [
          Icon(icon, size: 50, color: accent),
          const SizedBox(height: 12),
          Text(heading, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 8),
          Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: muted, fontSize: 12)),
        ]),
      );
}

class Artwork extends StatelessWidget {
  const Artwork({super.key, required this.song, this.size, this.radius = 16});
  final Song song;
  final double? size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    Widget cover;
    if (song.imageBase64 != null && song.imageBase64!.isNotEmpty) {
      try {
        cover = Image.memory(base64Decode(song.imageBase64!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback());
      } catch (_) { cover = _fallback(); }
    } else if (song.imageUrl?.startsWith('https://') == true) {
      cover = Image.network(song.imageUrl!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback());
    } else { cover = _fallback(); }
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Container(
        width: size ?? double.infinity,
        height: size,
        decoration: const BoxDecoration(color: Color(0xFF35452C)),
        child: size == null ? AspectRatio(aspectRatio: 1, child: cover) : cover,
      ),
    );
  }

  Widget _fallback() => Container(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF3A4D2E), Color(0xFF101515)])),
        child: const Center(child: Icon(Icons.album, size: 44, color: accent)),
      );
}

class StarPicker extends StatelessWidget {
  const StarPicker({super.key, required this.value, required this.onChanged});
  final double value;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, constraints) {
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (details) {
            final step = (details.localPosition.dx / constraints.maxWidth * 10).ceil().clamp(1, 10);
            onChanged(step / 2);
          },
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: List.generate(5, (index) {
            final fill = (value - index).clamp(0.0, 1.0).toDouble();
            return Expanded(child: Stack(alignment: Alignment.center, children: [
              const Icon(Icons.star_rounded, color: Color(0xFF616866), size: 40),
              ClipRect(child: Align(alignment: Alignment.centerLeft, widthFactor: fill,
                child: const Icon(Icons.star_rounded, color: accent, size: 40))),
            ]));
          })),
        );
      });
}

class AlbumPage extends StatelessWidget {
  const AlbumPage({super.key, required this.album});
  final List<RatingEntry> album;

  @override
  Widget build(BuildContext context) {
    final ordered = [...album]..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    final average = ordered.fold<double>(0, (sum, e) => sum + e.rating) / ordered.length;
    final knownCount = ordered.map((e) => e.albumTotalTracks).whereType<int>().fold<int>(0, (a, b) => math.max(a, b));
    final partial = knownCount == 0 || ordered.length < knownCount;
    return Scaffold(
      appBar: AppBar(backgroundColor: bg, title: const Text('side b.', style: TextStyle(color: accent, fontWeight: FontWeight.bold))),
      body: ListView(padding: const EdgeInsets.all(23), children: [
        Center(child: Artwork(song: Song(title: '', artist: '', album: album.first.album, platform: album.first.platform, imageUrl: album.first.imageUrl), size: 240)),
        const SizedBox(height: 22),
        Text(album.first.album, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineLarge),
        const SizedBox(height: 9),
        Text('${ordered.length}${knownCount > 0 ? '/$knownCount' : ''} faixas avaliadas • ${partial ? 'média parcial' : 'média final'}', textAlign: TextAlign.center, style: const TextStyle(color: muted)),
        const SizedBox(height: 12),
        Text('★ ${average.toStringAsFixed(2)} / 5', textAlign: TextAlign.center, style: const TextStyle(color: accent, fontSize: 30, fontWeight: FontWeight.w900)),
        const SizedBox(height: 25),
        const Text('FAIXAS AVALIADAS', style: TextStyle(color: muted, letterSpacing: 1.7, fontWeight: FontWeight.bold, fontSize: 11)),
        for (final song in ordered) ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(song.title),
          subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Text('★ ${song.rating.toStringAsFixed(1)}', style: const TextStyle(color: accent, fontWeight: FontWeight.bold)),
        ),
      ]),
    );
  }
}
