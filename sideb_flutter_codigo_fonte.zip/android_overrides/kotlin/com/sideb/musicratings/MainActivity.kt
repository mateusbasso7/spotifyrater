package com.sideb.musicratings

import android.content.ComponentName
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Bundle
import android.provider.Settings
import android.graphics.Bitmap
import android.util.Base64
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity : FlutterActivity() {
    private val channelName = "com.sideb.musicratings/media"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "hasPermission" -> result.success(permissionGranted())
                "requestPermission" -> {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    result.success(null)
                }
                "current" -> {
                    val platform = call.argument<String>("platform") ?: "spotify"
                    val controller = activeController(platform)
                    if (controller == null) {
                        result.success(null)
                    } else {
                        val meta = controller.metadata
                        val playback = controller.playbackState
                        val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
                            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
                        val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
                        val album = meta?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: "Álbum desconhecido"
                        val image = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                        val imageUrl = meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                            ?: meta?.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        result.success(mapOf(
                            "title" to title,
                            "artist" to artist,
                            "album" to album,
                            "duration" to (meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L),
                            "position" to (playback?.position ?: 0L),
                            "playing" to (playback?.state == android.media.session.PlaybackState.STATE_PLAYING),
                            "imageUrl" to (if (imageUrl?.startsWith("https://") == true) imageUrl else null),
                            "imageBase64" to convertArtwork(image)
                        ))
                    }
                }
                "control" -> {
                    val platform = call.argument<String>("platform") ?: "spotify"
                    val action = call.argument<String>("action") ?: ""
                    val controller = activeController(platform)
                    if (controller == null) {
                        result.success(false)
                    } else {
                        when (action) {
                            "previous" -> controller.transportControls.skipToPrevious()
                            "next" -> controller.transportControls.skipToNext()
                            "playPause" -> {
                                if (controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) {
                                    controller.transportControls.pause()
                                } else {
                                    controller.transportControls.play()
                                }
                            }
                        }
                        result.success(action in listOf("previous", "next", "playPause"))
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun permissionGranted(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").any { item ->
            ComponentName.unflattenFromString(item)?.packageName == packageName
        }
    }

    private fun activeController(platform: String): MediaController? {
        if (!permissionGranted()) return null
        val wanted = if (platform == "youtube") "com.google.android.apps.youtube.music" else "com.spotify.music"
        return try {
            val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val listener = ComponentName(this, MediaAccessListener::class.java)
            manager.getActiveSessions(listener).firstOrNull { it.packageName == wanted }
        } catch (_: SecurityException) {
            null
        }
    }

    private fun convertArtwork(image: Bitmap?): String? {
        if (image == null) return null
        return try {
            val scaled = Bitmap.createScaledBitmap(image, 450, 450, true)
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) { null }
    }
}
