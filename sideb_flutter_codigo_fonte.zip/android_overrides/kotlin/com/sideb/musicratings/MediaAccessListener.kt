package com.sideb.musicratings

import android.service.notification.NotificationListenerService

// O Android usa este serviço para permitir consultas às sessões de mídia.
// Não lemos, armazenamos ou transmitimos o conteúdo das notificações.
class MediaAccessListener : NotificationListenerService()
