# Side B. — App Android de avaliações musicais

Base Flutter + Kotlin (Android), sem backend e sem banco de dados externo. Preparada com o Client ID público do Spotify fornecido pelo proprietário do projeto. **O ZIP não é um APK.**

## O que funciona no código

- Login de Spotify com OAuth Authorization Code + PKCE, sem Client Secret; token guardado no armazenamento seguro Android.
- Consultar música atual e pesquisar faixas pelo Spotify Web API (quando a conta tem autorização e os endpoints estão disponíveis).
- Ler sessão de mídia do Spotify e YouTube Music do próprio Android, após o usuário habilitar acesso especial às notificações.
- Enviar play/pause/anterior/próxima pelas sessões de mídia; no Spotify, tentar API Web caso não exista sessão local.
- Dar nota de 0,5 até 5,0 a qualquer música detectada ou encontrada na pesquisa do Spotify.
- Guardar notas no dispositivo usando shared_preferences (sem nuvem ou conta Side B).
- Exibir álbuns agrupados, com média das faixas avaliadas e indicação de parcial quando ainda não se sabe o total de faixas ou faltam notas.
- Exportar notas e médias de álbuns em JSON e CSV pelo menu de compartilhamento Android; importar backup JSON; aviso **dentro do app** após sete dias sem exportação.

## Limites atuais

- **Não testado em aparelho físico nem compilado neste ambiente**: a compilação será testada pelo GitHub Actions. Verifique o primeiro resultado do workflow antes de instalar.
- O YouTube Music **não disponibiliza uma API oficial de player equivalente**; depende de sessão de mídia no Android. Se o aplicativo não a expuser, as informações e o controle não estarão disponíveis.
- O YouTube Music não tem pesquisa online implementada aqui. A busca online usa apenas o catálogo Spotify.
- O aviso semanal só aparece quando você abre o Side B. Não é uma notificação do Android em segundo plano.
- O total de músicas de um álbum só é conhecido em algumas respostas Spotify. A indicação “parcial” fica conservadora quando o total não é conhecido.
- Não há sincronização de avaliações entre aparelhos. A exportação JSON é o backup e pode ser importada.
- Spotify de desenvolvimento requer dono do app Spotify Premium e permite até 5 usuários autorizados, cadastrados em Users Management. O Spotify também limita requisições, e funcionalidades podem falhar com HTTP 403/429.
- O APK criado pelo workflow é uma versão **debug para testes**, não é destinado à Play Store.

## Spotify Developer Dashboard

Configure exatamente:

- App: `Side B`
- Redirect URI: `sideb://callback`
- Android package: `com.sideb.musicratings`
- Client ID: já configurado em `lib/src/spotify.dart`.
- Não cole Client Secret no app.
- Em **Users Management**, adicione os usuários autorizados (no máximo cinco em Development Mode).

O método OAuth implementado é Web API + PKCE. Ele **não exige Spotify Android App Remote SDK** e não usa o SHA-1 de assinatura do APK para conectar via PKCE. O SHA-1 poderá ser necessário em outros fluxos / SDKs adicionados futuramente.

## Como gerar o APK sem computador usando o GitHub

O `.github/workflows/android-apk.yml` foi preparado para gerar o projeto Android com Flutter e compilar o APK automaticamente.

1. Extraia este ZIP e envie todos os arquivos/pastas, incluindo a pasta oculta `.github`, para a raiz de um repositório GitHub privado (o Client ID é público, mas o projeto pode ser privado).
2. No GitHub do celular, abra o repositório e vá em **Actions**.
3. Abra **Compilar APK Android Side B** e toque em **Run workflow** (ou aguarde o workflow acionado pelo commit).
4. Quando o workflow ficar verde, abra a execução e baixe o artefato **sideb-android-apk**.
5. Extraia o APK do artefato ZIP e instale no Android. O telefone poderá pedir permissão para instalar apps dessa origem.

O workflow gera uma cópia Flutter Android em `/tmp/sideb-build`, copia os fontes do ZIP, executa `flutter pub get`, `flutter test` e `flutter build apk --debug`. Por isso, o ZIP contém código-fonte, overrides nativos e o workflow — não uma árvore de Gradle gerada localmente.

### Compilar em um computador no futuro

1. Instale Flutter SDK e Android SDK.
2. `flutter create --platforms=android --project-name=musicratings --org=com.sideb sideb-build`
3. Copie `pubspec.yaml`, `lib/`, `test/`, `android_overrides/AndroidManifest.xml` e `android_overrides/kotlin/...` para as respectivas posições dentro de `sideb-build/`.
4. Execute `flutter pub get`, `flutter test` e `flutter build apk --debug`.

## Permissões e privacidade

O Side B precisa de INTERNET para Spotify OAuth/API e imagens. O acesso às sessões de mídia exige habilitar manualmente o serviço Side B nas configurações de acesso a notificações do Android. O app não coleta nem exporta o conteúdo de notificações; usa essa permissão para consultar sessões ativas e comandos do player. Avaliações e backups permanecem sob controle do usuário.

## Estrutura

- `lib/main.dart`: interface Flutter escura, player e avaliações.
- `lib/src/model.dart`: modelos e serialização.
- `lib/src/storage.dart`: armazenamento local / JSON / CSV.
- `lib/src/spotify.dart`: OAuth PKCE / Web API Spotify.
- `lib/src/media.dart`: ponte Flutter para Android.
- `android_overrides/kotlin/...`: consulta e controle da sessão de mídia nativa.
- `.github/workflows/android-apk.yml`: gera projeto base e APK debug na nuvem.
