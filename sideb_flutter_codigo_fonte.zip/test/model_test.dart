import 'package:flutter_test/flutter_test.dart';
import 'package:musicratings/src/model.dart';

void main() {
  test('identidade da faixa é estável para mesma plataforma', () {
    const a = Song(title: 'Falling Away', artist: 'The Band', album: 'Album I', platform: 'spotify');
    const b = Song(title: 'Falling Away', artist: 'The Band', album: 'Album I', platform: 'spotify');
    const c = Song(title: 'Falling Away', artist: 'The Band', album: 'Album I', platform: 'youtube');
    expect(a.key, b.key);
    expect(a.key == c.key, isFalse);
  });

  test('avaliação passa pelo JSON para backup', () {
    const song = Song(title: 'Song', artist: 'Artist', album: 'Album', platform: 'spotify');
    final entry = RatingEntry.fromSong(song, 3.5);
    final loaded = RatingEntry.fromJson(entry.toJson());
    expect(loaded.rating, 3.5);
    expect(loaded.album, 'Album');
  });
}
